
<link rel="stylesheet" type="text/html" href="IncStageTop.html" media="screen" />

<!-- BEGIN FOOTER -->
<div id="footer">
  <div id="footer-nav">
  <span><a href="property-search" style="margin-left:8px; margin-right:8px;" title="Property Search">Property Search</a>|
  <a href="company" style="margin-left:8px; margin-right:8px;" title="Company">Company</a>|
  <a href="contact" style="margin-left:8px; margin-right:8px;" title="Contact Information">Contact</a>
  |<span style="margin-left:8px;">&copy;2017 Windermere Commercial</span></span>
  </div>
  </div>
<!-- END FOOTER -->
</body>
</html>
