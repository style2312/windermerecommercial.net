<!-- #include virtual="inc/incStageTop.asp" -->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Windermere Commercial </title>
	<meta name="description" content="Windermere Commercial Real Estate" />
	<meta name="keywords" content="commercial real estate, listings, commercial properties, for sale, for lease, spokane, coeur d'alene, eastern washington, inland northwest, north idaho, sds realty, seattle, tacoma, portland, bend, washington state, oregon, idaho, northwest, puget sound" />
	<meta name="robots" content="index, follow" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<div id="Index">
		<div id="header">
			<div id="header-top"></div>
			<div id="header-middle">   
				<div id="header-left"> 
					<img id="logo" src="images/logo.jpg"/>
						<div id="contact">
						<p>Our goal is to seek and maintain long term client relationships by offering innovative, creative and successful strategies tailored to meet each of our client's goals and objectives.</p>
						<h2><span>(509)</span> 747-1051</h2>
						<h3>2829 South Grand Blvd, Suite 101<br />
						Spokane, WA 99223</h3>
					</div>  
				</div>  
				<div id="middle-home-right" style="z-index:800;">
					<table id="top-nav">
						<tr>
							<td><a href="index.html"><div class="button">Home</div></a></td>
							<td><a href="agents.html"><div class="button">Our Agents</div></a></td>
							<td><a href="customSearch.html"><div class="button" id="search">Custom Search</div></a></td>
							<td><a href="aboutus.html"><div class="button" id="company">Our Company</div></a></td>
							<td><a href="contactus.html"><div class="button">Contact Us</div></a></td>
						</tr>
					</table>
					<div id="divOuterStyle" style="position:relative; width:755px; height:455px; line-height:0; overflow: hidden;">
						<div id="idPanel1" style="position: absolute; z-index: 5; opacity: 1;">
							<div id="idPlayWrapper1">
							   <img src="images/river.jpg" id="idTitleSlideImage1" width="755" height="455" style="z-index:95;">
							</div>
						</div>
						<div id="idPanel2" style="position: absolute; z-index: 5; opacity: 1;">
							<div id="idPlayWrapper2">
								<img src="images/hospitality.cb.jpg" id="idTitleSlideImage2" style="border:0; width:755px; height:455px; z-index:76;">
							</div>
						</div>
						<div id="idPanel3" style="position: absolute; z-index: 5; opacity: 1;">
							<div id="idPlayWrapper3">
								<img src="images/land.jpg" id="idTitleSlideImage3" style="border:0; width:755px; height:455px; z-index:76;">
							</div>
						</div>
					</div>
				</div>  
			</div> <!-- /header -->
			<div id="header-bottom"></div>
			<div id="column-mask">
				<div id="column-container">
					<ul id="home-property-buttons">
					  <li style="background:#E6EAF1;"><span><a href="office.html"><img class="property-images" src="Images\office.cb.jpg" /><p class="title">Office</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#F4F4F4;"><span><a href="industrial.html"><img class="property-images" src="Images\industrial.cb.jpg" /><p class="title">Industrial</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#D9DCD7;"><span><a href="retail.html"><img class="property-images" src="Images\retail.cb.jpg" /><p class="title">Retail</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#E6EAF1;"><span><a href="multi-family.html"><img class="property-images" src="Images\multifamily.cb.jpg" /><p class="title">Multi-Family</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#F4F4F4;"><span><a href="land.html"><img class="property-images" src="Images\land.cb.jpg" /><p class="title">Land</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#D9DCD7;"><span><a href="hospitality.html"><img class="property-images" src="Images\hospitality.cb.jpg" /><p class="title">Hospitality</p><p class="text">View Listings >></p></a></span></li>
					  <li style="background:#E6EAF1;"><span><a href="business.html"><img class="property-images" src="Images\business.cb.jpg" /><p class="title">Business</p><p class="text">View Listings >></p></a></span></li>
					</ul>
				</div> <!-- /column-container -->
			</div> <!-- /column-mask -->
		</div>
	</div>