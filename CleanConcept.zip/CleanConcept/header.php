<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Windermere Commercial </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="width" />
	<meta name="description" content="Windermere Commercial Real Estate" />
	<meta name="keywords" content="commercial real estate, listings, commercial properties, for sale, for lease, spokane, coeur d'alene, eastern washington, inland northwest, north idaho, sds realty, seattle, tacoma, portland, bend, washington state, oregon, idaho, northwest, puget sound" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<div class="main">
