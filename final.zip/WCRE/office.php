<!-- #include virtual="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\stagetop.php" -->

<div id="header">
  <div id="header-top"></div>
  <div id="header-middle">
    <div id="middle-left">
      <a href="index.php" id="logo"></a>
      <div id="contact">
        <h1>SDS Realty, Inc., Spokane Washington</h1>
        <h1>Commercial Real Estate Services ~ Established 1986</h1>
        <h2><span>(509) 624-1019</span></h2>
        <h3>108 N. Washington, Suite 500<br>
        Spokane, WA 99201</h3>
      </div>  <!-- /contact -->
    </div> <!-- /middle-left -->
    <div id="middle-right">
      <img src="images/header_photo.jpg" height="221" width="684" border="0"><br>
	</div> <!-- /middle-right -->
  </div> <!-- /header-middle -->
  <div id="header-bottom"></div>
  <div id="header-nav">
	<script>
        with(milonic=new menuname("Main Menu")){
        alwaysvisible=1;
        borderwidth=0;
        separatorsize=0;
        orientation="horizontal";
        style=menuStyle;
        aI("image=images/btn_spacer_left.gif;");
        aI("image=images/btn_home.gif;url=index.php;overimage=images/btn_home_ov.gif;");
        aI("showmenu=agents;image=images/btn_agents.gif;overimage=images/btn_agents_ov.gif;url=#;");
        aI("showmenu=properties;image=images/btn_properties.gif;overimage=images/btn_properties_ov.gif;url=#;");
        aI("showmenu=company;image=images/btn_company.gif;overimage=images/btn_company_ov.gif;url=#;");
        }
        drawMenus();
    </script><div class="mmenucontainer" onmouseout="$I()" onmouseover="$jJ(3)" onselectstart="return 0" id="menu3" style="padding: 0px; z-index: 999; visibility: visible; position: absolute;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" id="tbl3"><tbody><tr><td id="el17" onmouseover="h$(17,0,1)" style="padding:0px;;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" width="100%" height="100%" id="MTbl17"><tbody><tr id="td17"><td id="_imgO17"><img onload="_p2(3,this)" border="0" style="display: block; width: 288px;" id="_img17" src="images/btn_spacer_left.gif"></td></tr></tbody></table></td><td id="el18" onmouseover="h$(18,0,1)" style="padding:0px;;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" width="100%" height="100%" id="MTbl18"><tbody><tr id="td18"><td id="_imgO18"><img onload="_p2(3,this)" border="0" style="display: block; width: 148px;" id="_img18" src="images/btn_home.gif"></td></tr></tbody></table></td><td id="el19" onmouseover="h$(19,0,1)" style="padding:0px;;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" width="100%" height="100%" id="MTbl19"><tbody><tr id="td19"><td id="_imgO19"><img onload="_p2(3,this)" border="0" style="display: block; width: 160px;" id="_img19" src="images/btn_agents.gif"></td></tr></tbody></table></td><td id="el20" onmouseover="h$(20,0,1)" style="padding:0px;;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" width="100%" height="100%" id="MTbl20"><tbody><tr id="td20"><td id="_imgO20"><img onload="_p2(3,this)" border="0" style="display: block; width: 216px;" id="_img20" src="images/btn_properties.gif"></td></tr></tbody></table></td><td id="el21" onmouseover="h$(21,0,1)" style="padding:0px;;"><table class="milonictable" border="0" cellpadding="0" cellspacing="0" style="line-height:normal;padding:0px;" width="100%" height="100%" id="MTbl21"><tbody><tr id="td21"><td id="_imgO21"><img onload="_p2(3,this)" border="0" style="display: block; width: 160px;" id="_img21" src="images/btn_company.gif"></td></tr></tbody></table></td></tr></tbody></table> <a name="mM1" id="mmlink3" href="#" onclick="return $K(this._itemRef)" onmouseover="_p1(this);_mot=$P(_mot)" style="outline: none; line-height: normal; background: transparent; text-decoration: none; height: 1px; width: 1px; overflow: hidden; position: absolute; visibility: hidden;"></a></div>    
  </div> <!-- /header-nav -->
</div>
<!-- #include virtual="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\stagebottom.html" -->