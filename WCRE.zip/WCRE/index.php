<link rel="stylesheet" type="text/css" href="IncStageTop.html" media="screen" />
<link rel="stylesheet" type="text/css" href="IncStagebottom.html" media="screen" />
<div id="header">
  <div id="header-top"></div>
  <div id="header-middle">   
	<div id="header-left"> 
		<img id="logo" src="images/logo.jpg"/>
		<div style="height:15px; width:300px;"></div>
		<div id="contact">
			<p>Our goal is to seek and maintain long term client relationships by offering innovative, creative and successful strategies tailored to meet each of our client's goals and objectives.</p>
			<h2><span>(509)</span> 747-1051</h2>
			<h3>2829 South Grand Blvd, Suite 101<br />
			Spokane, WA 99223</h3>
		</div>  
    </div>  
    <div id="middle-home-right"  class="slideshow" style="z-index:800;">
		<table>
			<tr>
				<td><div class="button">Home</div></td>
				<td><div class="button">Our Agents</div></td>
				<td><div class="button" id="search">Custom Search</div></td>
				<td><div class="button" id="search">Our Company</div></td>
				<td><div class="button">Contact Us</div></td>
			</tr>
		</table>
		<div id="button-mask">
 
</div>
        <img src="Images\river.jpg" height="435" width="700" border="0">
	</div> <!-- /middle-home-right -->
  </div> <!-- /header-middle -->
  <div id="header-bottom"></div>
</div> <!-- /header -->


<div id="column-mask">
  <div id="column-container">
	<ul id="home-property-buttons">
      <li style="background:#E6EAF1;"><span><a href="office.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\office.jpg" /><p class="title">Office</p><p class="text">View Listings >></p></a></span></li>
      <li style="background:#D9DCD7;"><span><a href="retail.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\retail.jpg" /><p class="title">Retail</p><p class="text">View Listings >></p></a></span></li>
	  <li style="background:#F4F4F4;"><span><a href="industrial.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\industrial.jpg" /><p class="title">Industrial</p><p class="text">View Listings >></p></a></span></li>
      <li style="background:#E6EAF1;"><span><a href="multi-family.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\multifamily.jpg" /><p class="title">Multi-Family</p><p class="text">View Listings >></p></a></span></li>
      <li style="background:#D9DCD7;"><span><a href="land.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\land.jpg" /><p class="title">Land</p><p class="text">View Listings >></p></a></span></li>
      <li style="background:#F4F4F4;"><span><a href="hospitality.html"><img class="property-images" src="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\Images\hospitality.cb.jpg" /><p class="title">Mixed Use</p><p class="text">View Listings >></p></a></span></li>
	</ul>
  </div> <!-- /column-container -->
</div> <!-- /column-mask -->
<!-- #include virtual="C:\Users\Crystal\Documents\WINDERMERE WEBSITE\stagebottom.html" -->